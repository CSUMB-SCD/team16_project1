package edu.csumb.cst438.otterBuyService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OtterBuyServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(OtterBuyServiceApplication.class, args);
	}
}
